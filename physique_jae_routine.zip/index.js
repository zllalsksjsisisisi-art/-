
export default function PhysiqueJaeRoutine() {
  return (
    <div className="min-h-screen bg-black text-white p-8 font-sans">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">Physique_jae 프로그램 루틴</h1>
        <p className="text-lg text-gray-400 mt-2">상위 0.0001% 피지컬을 위한 하드코어 루틴</p>
        <button className="mt-6 px-6 py-2 bg-red-600 rounded-xl hover:bg-red-700 transition">루틴 보기</button>
      </header>

      <section className="max-w-4xl mx-auto grid gap-10">
        <div className="bg-gray-900 p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-semibold mb-2">🔥 주간 루틴 구성</h2>
          <ul className="list-disc list-inside text-gray-300">
            <li>월: 가슴 + 전면삼각근 (프레스 중심)</li>
            <li>화: 등 + 후면삼각근 (넓이 + 두께)</li>
            <li>수: 하체 (쿼드 집중)</li>
            <li>목: 어깨 + 팔 (델트 분할, 슈퍼셋)</li>
            <li>금: 하체 (햄스트링/둔근)</li>
            <li>토: 가슴 or 약점 보완</li>
            <li>일: 휴식 or 포징/스트레칭</li>
          </ul>
        </div>

        <div className="bg-gray-900 p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-semibold mb-2">💪 월요일 루틴 예시</h2>
          <ol className="list-decimal list-inside text-gray-300">
            <li>인클라인 스미스 프레스 – 4세트 (10-8-6-6)</li>
            <li>플랫 덤벨 프레스 – 4세트 (12-10-8-8)</li>
            <li>펙덱 플라이 – 4세트 (15-12-12-10)</li>
            <li>딥스 (머신 or 체중) – 3세트 (최대 반복)</li>
            <li>프론트 레이즈 – 4세트 (12~15회)</li>
          </ol>
        </div>

        <div className="bg-gray-900 p-6 rounded-2xl shadow-xl">
          <h2 className="text-2xl font-semibold mb-2">📩 커스터마이징 문의</h2>
          <p className="text-gray-300 mb-2">루틴을 개인에게 맞춰 수정하고 싶다면 아래로 연락주세요.</p>
          <p className="text-red-400">📧 physique.jae@gmail.com</p>
          <p className="text-blue-400">📱 Instagram: @physique_jae</p>
        </div>
      </section>
    </div>
  );
}
